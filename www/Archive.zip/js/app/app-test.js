;(function() {
		alert("dinamo");
	for (var i = 0; i < 3; i++) {
			alert("dinamo " + i);
		alert(window.app.data.cities[0].name);
	};
}());